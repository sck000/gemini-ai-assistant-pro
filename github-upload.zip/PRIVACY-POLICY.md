# Privacy Policy - Gemini AI Assistant Pro

**Effective Date:** December 2024  
**Version:** 2.6.0

## Overview

Gemini AI Assistant Pro è un'estensione Chrome che fornisce funzionalità di assistente AI utilizzando i servizi Gemini di Google. La tua privacy è importante per noi.

## Data Collection

### Data We Collect
- **Content Interactions**: Il testo che invii per l'elaborazione AI viene temporaneamente processato per fornirti risposte
- **Settings Preferences**: Le tue impostazioni (modello AI, temperatura, ecc.) vengono salvate localmente
- **Usage Analytics**: Dati aggregati e anonimi sull'utilizzo delle funzionalità

### Data We DON'T Collect
- **Personal Information**: Non raccogliamo informazioni personali identificative
- **Browsing History**: Non tracciamo o salviamo la tua cronologia di navigazione
- **Passwords or Sensitive Data**: Non accediamo o salviamo password o dati sensibili

## Data Usage

### How We Use Your Data
- **AI Processing**: Il contenuto viene inviato ai servizi Gemini per l'elaborazione AI
- **Service Improvement**: Dati aggregati per migliorare l'estensione
- **Local Storage**: Le impostazioni vengono salvate localmente nel tuo browser

### Data Sharing
- **Third Parties**: Condividiamo dati solo con Google Gemini per l'elaborazione AI
- **No Selling**: Non vendiamo mai i tuoi dati a terze parti
- **Legal Requirements**: Potremmo condividere dati se richiesto dalla legge

## Data Storage

### Local Storage
- **Settings**: Salvate nel Chrome storage locale
- **API Keys**: Se fornite, vengono salvate localmente e criptate
- **Temporary Data**: Contenuto processato temporaneamente, non salvato permanentemente

### External Services
- **Google Gemini**: I contenuti vengono processati secondo la [Privacy Policy di Google](https://policies.google.com/privacy)

## User Rights

### Your Controls
- **Data Access**: Puoi accedere alle tue impostazioni tramite l'interfaccia dell'estensione
- **Data Deletion**: Puoi cancellare le impostazioni rimuovendo l'estensione
- **Opt-out**: Puoi disabilitare funzionalità specifiche nelle impostazioni

### Data Retention
- **Local Data**: Rimane finché non rimuovi l'estensione
- **Processed Content**: Non salvato permanentemente sui nostri server
- **Analytics**: Dati aggregati mantenuti per miglioramenti del servizio

## Security

### Data Protection
- **Encryption**: API keys e dati sensibili vengono criptati
- **Secure Transmission**: Tutte le comunicazioni utilizzano HTTPS
- **No Plaintext Storage**: Nessun dato sensibile salvato in chiaro

## Changes to Privacy Policy

Ti notificheremo eventuali modifiche significative a questa policy tramite aggiornamenti dell'estensione.

## Contact

Per domande su questa privacy policy, contatta:
- **Email**: [privacy@gemini-ai-assistant.com]
- **GitHub**: [Repository Issues]

## Compliance

Questa estensione è conforme a:
- **GDPR** (General Data Protection Regulation)
- **CCPA** (California Consumer Privacy Act)
- **Chrome Web Store Policies**

---

*Ultimo aggiornamento: Dicembre 2024* 