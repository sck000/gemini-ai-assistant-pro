// Internationalization system
function initializeI18n() {
    const elements = document.querySelectorAll('[data-i18n]');
    elements.forEach(element => {
        const key = element.getAttribute('data-i18n');
        const message = chrome.i18n.getMessage(key);
        if (message) {
            element.textContent = message;
        }
    });

    // Handle placeholders
    const placeholderElements = document.querySelectorAll('[data-i18n-placeholder]');
    placeholderElements.forEach(element => {
        const key = element.getAttribute('data-i18n-placeholder');
        const message = chrome.i18n.getMessage(key);
        if (message) {
            element.placeholder = message;
        }
    });
}

// Prompt generation with i18n support
function getLocalizedPrompt(key, variables = {}) {
    let prompt = chrome.i18n.getMessage(key);
    
    // Replace variables in the prompt template
    Object.keys(variables).forEach(varKey => {
        prompt = prompt.replace(new RegExp(`{${varKey}}`, 'g'), variables[varKey]);
    });
    
    return prompt;
}

function getLocalizedThinkingMessage(key) {
    return chrome.i18n.getMessage(key) || 'Processing...';
}

// Gemini AI Assistant - ChatGPT Style Interface
class GeminiChatInterface {
    constructor() {
        this.messages = [];
        this.isLoading = false;
        this.settings = {};
        
        try {
            this.init();
        } catch (error) {
            console.error('Error initializing chat interface:', error);
            this.showErrorState(error.message);
        }
    }

    async init() {
        this.setupEventListeners();
        await this.loadSettings();
        await this.loadLanguageSettings();
        this.initializeInterface();
        
        // Inizializza l'internazionalizzazione
        initializeI18n();
    }

    async loadSettings() {
        try {
            this.settings = await chrome.storage.sync.get([
                'apiKey', 'model', 'maxTokens', 'temperature'
            ]);
            
            // Controlla se l'API Key è configurata
            if (!this.settings.apiKey) {
                this.showApiKeyWarning();
            }
        } catch (error) {
            console.error('Failed to load settings:', error);
            this.showApiKeyWarning();
        }
    }

    async loadLanguageSettings() {
        try {
            const result = await chrome.storage.sync.get(['language']);
            if (result.language) {
                // La lingua è gestita dall'estensione tramite i file _locales
                console.log('Language setting:', result.language);
            }
        } catch (error) {
            console.error('Failed to load language settings:', error);
        }
    }

    setupEventListeners() {
        // Input handling
        const input = document.getElementById('main-input');
        const sendBtn = document.getElementById('main-send');

        input.addEventListener('input', () => {
            this.autoResizeInput();
            this.toggleSendButton();
        });

        input.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                this.handleSendMessage();
            }
        });

        sendBtn.addEventListener('click', () => this.handleSendMessage());

        // Quick suggestions
        document.querySelectorAll('.suggestion-item').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const action = e.currentTarget.dataset.action;
                this.handleQuickAction(action);
            });
        });

        // Settings button
        document.getElementById('open-options').addEventListener('click', () => {
            chrome.runtime.openOptionsPage();
        });
    }

    showApiKeyWarning() {
        const welcomeSection = document.getElementById('welcome-section');
        if (welcomeSection) {
            welcomeSection.innerHTML = `
                <div class="welcome-content">
                    <div class="welcome-icon">⚠️</div>
                    <h2>${chrome.i18n.getMessage('popupApiKeyNeeded')}</h2>
                    <p>${chrome.i18n.getMessage('popupApiKeyMessage')}</p>
                    
                    <button id="open-settings-btn" class="suggestion-item" style="margin: 16px auto; max-width: 280px;">
                        <div class="suggestion-icon">⚙️</div>
                        <span>${chrome.i18n.getMessage('popupOpenSettings')}</span>
                    </button>
                    
                    <p style="font-size: 12px; color: #6b7280; margin-top: 16px;">
                        ${chrome.i18n.getMessage('popupGetApiKey')} 
                        <a href="https://aistudio.google.com/app/apikey" target="_blank" style="color: #667eea;">Google AI Studio</a>
                    </p>
                </div>
            `;
            
            // Aggiungi listener per il pulsante delle impostazioni
            const settingsBtn = document.getElementById('open-settings-btn');
            if (settingsBtn) {
                settingsBtn.addEventListener('click', () => {
                    chrome.runtime.openOptionsPage();
                });
            }
        }
    }

    initializeInterface() {
        this.autoResizeInput();
        this.toggleSendButton();
    }

    autoResizeInput() {
        const input = document.getElementById('main-input');
        input.style.height = 'auto';
        input.style.height = Math.min(input.scrollHeight, 120) + 'px';
    }

    toggleSendButton() {
        const input = document.getElementById('main-input');
        const sendBtn = document.getElementById('main-send');
        const hasText = input.value.trim().length > 0;
        
        sendBtn.disabled = !hasText || this.isLoading;
        sendBtn.style.opacity = hasText && !this.isLoading ? '1' : '0.5';
    }

    async handleSendMessage() {
        const input = document.getElementById('main-input');
        const message = input.value.trim();
        
        if (!message || this.isLoading) return;

        // Controlla se l'API Key è configurata
        if (!this.settings.apiKey) {
            this.addMessage(`⚠️ ${chrome.i18n.getMessage('errorApiKeyMissing')}`, 'error');
            return;
        }

        // Clear input and reset height
        input.value = '';
        this.autoResizeInput();
        this.toggleSendButton();

        // Add user message
        this.addMessage(message, 'user');
        this.showWelcomeSection(false);

        // Start loading
        this.setLoading(true);
        this.addLoadingMessage();

        try {
            const response = await this.processMessage(message);
            this.removeLoadingMessage();
            this.addMessage(response, 'assistant');
        } catch (error) {
            this.removeLoadingMessage();
            this.addMessage(`Errore: ${error.message}`, 'error');
        } finally {
            this.setLoading(false);
        }
    }

    async handleQuickAction(action) {
        if (this.isLoading) return;

        // Controlla se l'API Key è configurata
        if (!this.settings.apiKey) {
            this.addMessage(`⚠️ ${chrome.i18n.getMessage('errorApiKeyMissing')}`, 'error');
            return;
        }

        let message = '';
        let systemPrompt = '';

        switch (action) {
            case 'summarize':
                message = chrome.i18n.getMessage('actionSummarize');
                systemPrompt = await this.buildPageAnalysisPrompt('riassumi');
                break;
            case 'translate':
                const selectedText = await this.getSelectedText();
                if (!selectedText) {
                    this.addMessage(chrome.i18n.getMessage('popupErrorSelectText'), 'error');
                    return;
                }
                message = `${chrome.i18n.getMessage('actionTranslate')}: "${selectedText.substring(0, 100)}${selectedText.length > 100 ? '...' : ''}"`;
                systemPrompt = `Traduci questo testo in italiano:\n\n"${selectedText}"`;
                break;
            case 'explain':
                const selectedForExplain = await this.getSelectedText();
                if (!selectedForExplain) {
                    this.addMessage(chrome.i18n.getMessage('popupErrorSelectExplain'), 'error');
                    return;
                }
                message = `${chrome.i18n.getMessage('actionExplain')}: "${selectedForExplain.substring(0, 100)}${selectedForExplain.length > 100 ? '...' : ''}"`;
                systemPrompt = `Spiega in modo semplice e chiaro questo testo:\n\n"${selectedForExplain}"`;
                break;
            case 'improve':
                const selectedForImprove = await this.getSelectedText();
                if (!selectedForImprove) {
                    this.addMessage(chrome.i18n.getMessage('popupErrorSelectImprove'), 'error');
                    return;
                }
                message = `${chrome.i18n.getMessage('actionImprove')}: "${selectedForImprove.substring(0, 100)}${selectedForImprove.length > 100 ? '...' : ''}"`;
                systemPrompt = `Migliora questo testo rendendolo più chiaro e ben scritto:\n\n"${selectedForImprove}"`;
                break;
        }

        if (message && systemPrompt) {
            this.addMessage(message, 'user');
            this.showWelcomeSection(false);
            this.setLoading(true);
            this.addLoadingMessage();

            try {
                const response = await this.callGeminiAPI(systemPrompt);
                this.removeLoadingMessage();
                this.addMessage(response, 'assistant');
            } catch (error) {
                this.removeLoadingMessage();
                this.addMessage(`Errore: ${error.message}`, 'error');
            } finally {
                this.setLoading(false);
            }
        }
    }

    async processMessage(message) {
        // Check if it's a page-related question
        const lowerMessage = message.toLowerCase();
        const pageKeywords = ['pagina', 'page', 'questa', 'this', 'qui', 'here', 'sito', 'website'];
        
        if (pageKeywords.some(keyword => lowerMessage.includes(keyword))) {
            const pageContext = await this.getPageContext();
            const contextPrompt = `Basandoti sul contenuto di questa pagina web, rispondi alla seguente domanda:
            
Domanda: ${message}

Contesto della pagina:
Titolo: ${pageContext.title}
URL: ${pageContext.url}
Contenuto: ${pageContext.content.substring(0, 3000)}...`;
            
            return await this.callGeminiAPI(contextPrompt);
        }

        // General question
        return await this.callGeminiAPI(message);
    }

    async buildPageAnalysisPrompt(type) {
        const pageContext = await this.getPageContext();
        
        switch (type) {
            case 'riassumi':
                return `Riassumi il contenuto principale di questa pagina web:

Titolo: ${pageContext.title}
URL: ${pageContext.url}
Contenuto: ${pageContext.content.substring(0, 4000)}...

Fornisci un riassunto conciso e ben strutturato dei punti principali.`;
            default:
                return '';
        }
    }

    async callGeminiAPI(prompt) {
        if (!this.settings.apiKey) {
            throw new Error('API Key non configurata. Apri le impostazioni per configurarla.');
        }

        const model = this.settings.model || 'gemini-1.5-flash';
        const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${this.settings.apiKey}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                contents: [{
                    parts: [{
                        text: prompt
                    }]
                }],
                generationConfig: {
                    temperature: this.settings.temperature || 0.7,
                    topK: 40,
                    topP: 0.95,
                    maxOutputTokens: this.settings.maxTokens || 1024,
                }
            })
        });

        if (!response.ok) {
            if (response.status === 403) {
                throw new Error('API Key non valida o quota esaurita');
            } else if (response.status === 429) {
                throw new Error('Troppe richieste. Attendi qualche secondo');
            }
            throw new Error(`Errore API: ${response.status}`);
        }

        const data = await response.json();
        
        if (!data.candidates || !data.candidates[0] || !data.candidates[0].content) {
            throw new Error('Risposta non valida dall\'API');
        }

        return data.candidates[0].content.parts[0].text;
    }

    addMessage(content, type) {
        const message = { content, type, timestamp: Date.now() };
        this.messages.push(message);
        this.renderMessage(message);
        this.scrollToBottom();
    }

    renderMessage(message) {
        const container = document.getElementById('messages-container');
        const messageDiv = document.createElement('div');
        messageDiv.className = `message message-${message.type}`;
        
        const contentDiv = document.createElement('div');
        contentDiv.className = 'message-content';
        
        if (message.type === 'assistant') {
            // Format assistant messages with markdown support
            contentDiv.innerHTML = this.formatMessage(message.content);
        } else {
            contentDiv.textContent = message.content;
        }
        
        messageDiv.appendChild(contentDiv);
        container.appendChild(messageDiv);
    }

    formatMessage(content) {
        // Basic markdown formatting
        return content
            .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
            .replace(/\*(.*?)\*/g, '<em>$1</em>')
            .replace(/\n/g, '<br>');
    }

    addLoadingMessage() {
        const container = document.getElementById('messages-container');
        const loadingDiv = document.createElement('div');
        loadingDiv.className = 'message message-loading';
        loadingDiv.id = 'loading-message';
        
        loadingDiv.innerHTML = `
            <div class="message-content">
                <span>${chrome.i18n.getMessage('popupThinking')}</span>
                <div class="loading-dots">
                    <div class="loading-dot"></div>
                    <div class="loading-dot"></div>
                    <div class="loading-dot"></div>
                </div>
            </div>
        `;
        
        container.appendChild(loadingDiv);
        this.scrollToBottom();
    }

    removeLoadingMessage() {
        const loadingMsg = document.getElementById('loading-message');
        if (loadingMsg) {
            loadingMsg.remove();
        }
    }

    showWelcomeSection(show) {
        const welcomeSection = document.getElementById('welcome-section');
        const messagesContainer = document.getElementById('messages-container');
        
        if (show) {
            welcomeSection.style.display = 'flex';
            messagesContainer.style.display = 'none';
        } else {
            welcomeSection.style.display = 'none';
            messagesContainer.style.display = 'block';
        }
    }

    scrollToBottom() {
        const container = document.getElementById('messages-container');
        setTimeout(() => {
            container.scrollTop = container.scrollHeight;
        }, 100);
    }

    setLoading(loading) {
        this.isLoading = loading;
        this.toggleSendButton();
    }

    async getPageContext() {
        return new Promise((resolve) => {
            try {
                chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
                    if (chrome.runtime.lastError) {
                        console.error('Error querying tabs:', chrome.runtime.lastError);
                        resolve({ title: 'Pagina corrente', url: '', content: '' });
                        return;
                    }
                    
                    if (!tabs || !tabs[0]) {
                        resolve({ title: 'Pagina corrente', url: '', content: '' });
                        return;
                    }

                    chrome.scripting.executeScript({
                        target: { tabId: tabs[0].id },
                        function: () => ({
                            title: document.title,
                            url: window.location.href,
                            content: document.body.innerText.substring(0, 5000)
                        })
                    }, (results) => {
                        if (chrome.runtime.lastError) {
                            console.error('Error executing script:', chrome.runtime.lastError);
                            resolve({ title: 'Pagina corrente', url: '', content: '' });
                            return;
                        }
                        
                        if (results && results[0] && results[0].result) {
                            resolve(results[0].result);
                        } else {
                            resolve({ title: 'Pagina corrente', url: '', content: '' });
                        }
                    });
                });
            } catch (error) {
                console.error('Error in getPageContext:', error);
                resolve({ title: 'Pagina corrente', url: '', content: '' });
            }
        });
    }

    async getSelectedText() {
        return new Promise((resolve) => {
            try {
                chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
                    if (chrome.runtime.lastError) {
                        console.error('Error querying tabs:', chrome.runtime.lastError);
                        resolve('');
                        return;
                    }
                    
                    if (!tabs || !tabs[0]) {
                        resolve('');
                        return;
                    }

                    chrome.tabs.sendMessage(tabs[0].id, { type: 'getSelectedText' }, (response) => {
                        if (chrome.runtime.lastError) {
                            console.error('Error sending message:', chrome.runtime.lastError);
                            resolve('');
                            return;
                        }
                        resolve(response || '');
                    });
                });
            } catch (error) {
                console.error('Error in getSelectedText:', error);
                resolve('');
            }
        });
    }

    showErrorState(message) {
        const app = document.querySelector('.app');
        if (app) {
            app.innerHTML = `
                <div style="padding: 40px 20px; text-align: center; height: 100%; display: flex; flex-direction: column; justify-content: center;">
                    <div style="color: #dc2626; font-size: 48px; margin-bottom: 16px;">⚠️</div>
                    <h3 style="color: #dc2626; margin-bottom: 12px;">Errore nell'inizializzazione</h3>
                    <p style="color: #6b7280; margin-bottom: 20px; font-size: 14px;">${message}</p>
                    <button id="reload-popup-btn" style="padding: 12px 24px; background: #667eea; color: white; border: none; border-radius: 8px; cursor: pointer; font-size: 14px;">
                        Ricarica Popup
                    </button>
                </div>
            `;
            
            // Aggiungi event listener per il pulsante di ricarica
            const reloadBtn = document.getElementById('reload-popup-btn');
            if (reloadBtn) {
                reloadBtn.addEventListener('click', () => {
                    location.reload();
                });
            }
        }
    }
}

// Initialize the chat interface when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    console.log('Popup DOM loaded, initializing...');
    
    // Debug: controlla le dimensioni del popup
    console.log('Window dimensions:', {
        innerWidth: window.innerWidth,
        innerHeight: window.innerHeight,
        outerWidth: window.outerWidth,
        outerHeight: window.outerHeight
    });
    
    const body = document.body;
    const app = document.querySelector('.app');
    console.log('Body dimensions:', {
        clientWidth: body.clientWidth,
        clientHeight: body.clientHeight,
        scrollWidth: body.scrollWidth,
        scrollHeight: body.scrollHeight
    });
    
    if (app) {
        console.log('App dimensions:', {
            clientWidth: app.clientWidth,
            clientHeight: app.clientHeight,
            offsetWidth: app.offsetWidth,
            offsetHeight: app.offsetHeight
        });
    }
    
    // Verifica che il CSS si sia caricato controllando se .app ha gli stili corretti
    const checkCSS = () => {
        const styles = window.getComputedStyle(app);
        // Controlla multiple proprietà CSS per essere sicuri
        const hasFlexDisplay = styles.display === 'flex';
        const hasCorrectWidth = styles.width === '400px' || parseInt(styles.width) > 300;
        const hasBackground = styles.backgroundColor !== 'rgba(0, 0, 0, 0)' && styles.backgroundColor !== 'transparent';
        
        if (hasFlexDisplay || hasCorrectWidth || hasBackground) {
            document.body.classList.add('css-loaded');
            console.log('CSS loaded successfully');
            return true;
        }
        return false;
    };
    
    // Prova subito
    if (!checkCSS()) {
        console.log('CSS not loaded immediately, retrying...');
        // Riprova dopo un breve delay
        setTimeout(() => {
            if (!checkCSS()) {
                console.log('CSS still not loaded after retry, proceeding anyway');
                // Aggiunge comunque la classe per evitare il fallback
                document.body.classList.add('css-loaded');
            } else {
                console.log('CSS loaded on retry');
            }
        }, 100);
    }
    
    // Verifica che tutti gli elementi essenziali siano presenti
    const requiredElements = [
        'main-input',
        'main-send', 
        'welcome-section',
        'messages-container',
        'open-options'
    ];
    
    const missingElements = requiredElements.filter(id => !document.getElementById(id));
    
    if (missingElements.length > 0) {
        console.error('Missing elements:', missingElements);
        // Mostra un messaggio di errore
        document.body.innerHTML = `
            <div style="padding: 20px; text-align: center; font-family: Arial, sans-serif;">
                <h3 style="color: #dc2626;">Errore di caricamento</h3>
                <p>Alcuni elementi del popup non sono stati caricati correttamente.</p>
                <p style="font-size: 12px; color: #6b7280;">Elementi mancanti: ${missingElements.join(', ')}</p>
                <button id="reload-popup-btn2" style="margin-top: 10px; padding: 8px 16px; background: #667eea; color: white; border: none; border-radius: 6px; cursor: pointer;">
                    Ricarica
                </button>
            </div>
        `;
        
        // Aggiungi event listener per il pulsante di ricarica
        setTimeout(() => {
            const reloadBtn = document.getElementById('reload-popup-btn2');
            if (reloadBtn) {
                reloadBtn.addEventListener('click', () => {
                    location.reload();
                });
            }
        }, 100);
        
        return;
    }
    
    console.log('All elements found, initializing chat interface...');
    new GeminiChatInterface();
}); 