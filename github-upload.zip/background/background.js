// Background Script per Gemini AI Assistant Pro v2.6.0

// Setup quando l'estensione viene installata
chrome.runtime.onInstalled.addListener(() => {
    console.log('Gemini AI Assistant Pro v2.6.0 installato');
    
    // Crea context menus
    chrome.contextMenus.create({
        id: 'translate-text',
        title: 'Traduci con Gemini',
        contexts: ['selection']
    });
    
    chrome.contextMenus.create({
        id: 'explain-text',
        title: 'Spiega con Gemini',
        contexts: ['selection']
    });
    
    chrome.contextMenus.create({
        id: 'summarize-text',
        title: 'Riassumi con Gemini',
        contexts: ['selection']
    });
    
    chrome.contextMenus.create({
        id: 'improve-text',
        title: 'Migliora con Gemini',
        contexts: ['selection']
    });
    
    chrome.contextMenus.create({
        id: 'analyze-page',
        title: 'Analizza pagina con Gemini',
        contexts: ['page']
    });
});

// Gestione click context menu
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
    const selectedText = info.selectionText;
    
    try {
        let prompt = '';
        
        switch (info.menuItemId) {
            case 'translate-text':
                prompt = `Traduci questo testo in italiano:\n\n"${selectedText}"`;
                break;
            case 'explain-text':
                prompt = `Spiega in modo semplice e chiaro questo testo:\n\n"${selectedText}"`;
                break;
            case 'summarize-text':
                prompt = `Riassumi brevemente questo testo:\n\n"${selectedText}"`;
                break;
            case 'improve-text':
                prompt = `Come esperto di scrittura, migliora questo testo rendendolo più chiaro, fluido e ben scritto:\n\n"${selectedText}"\n\nFornisci solo il testo migliorato, senza commenti aggiuntivi.`;
                break;
            case 'analyze-page':
                // Per l'analisi pagina, ottieniamo il contenuto
                const [result] = await chrome.scripting.executeScript({
                    target: { tabId: tab.id },
                    function: () => ({
                        title: document.title,
                        url: window.location.href,
                        content: document.body.innerText.substring(0, 3000)
                    })
                });
                
                prompt = `Analizza questa pagina web e fornisci:\n1. Argomento principale\n2. Punti chiave\n3. Credibilità delle informazioni\n4. Riassunto per punti\n\nURL: ${result.result.url}\nTitolo: ${result.result.title}\nContenuto: ${result.result.content}...`;
                break;
        }
        
        if (prompt) {
            // Mostra indicatore di caricamento nel content script
            try {
                await chrome.tabs.sendMessage(tab.id, {
                    type: 'showLoading',
                    data: {
                        message: info.menuItemId === 'analyze-page' ? 
                            'Analizzando la pagina...' : 
                            'Gemini sta elaborando...'
                    }
                });
            } catch (msgError) {
                console.log('Content script not ready for loading message');
            }

            // Invia il prompt all'API Gemini
            const response = await processWithGemini(prompt);
            
            // Invia il risultato al content script per mostrarlo nel popup personalizzato
            await chrome.tabs.sendMessage(tab.id, {
                type: 'showNotification',
                data: {
                    type: 'result',
                    content: response
                }
            });
        }
        
    } catch (error) {
        console.error('Context menu error:', error);
        
        // Invia l'errore al content script per mostrarlo nel popup personalizzato
        try {
            await chrome.tabs.sendMessage(tab.id, {
                type: 'showNotification',
                data: {
                    type: 'error',
                    content: error.message
                }
            });
        } catch (msgError) {
            // Fallback a notifica di sistema se il content script non è disponibile
            chrome.notifications.create({
                type: 'basic',
                iconUrl: '../assets/icons/icon-48.png',
                title: 'Gemini AI Assistant',
                message: 'Errore: ' + error.message
            });
        }
    }
});

// Gestione keyboard shortcuts
chrome.commands.onCommand.addListener(async (command) => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    
    switch (command) {
        case 'open-assistant':
            // Apri popup dell'assistente
            chrome.action.openPopup();
            break;
            
        case 'analyze-page':
            // Analizza la pagina corrente
            try {
                // Mostra indicatore di caricamento
                try {
                    await chrome.tabs.sendMessage(tab.id, {
                        type: 'showLoading',
                        data: {
                            message: 'Analizzando la pagina...'
                        }
                    });
                } catch (msgError) {
                    console.log('Content script not ready for loading message');
                }

                const [result] = await chrome.scripting.executeScript({
                    target: { tabId: tab.id },
                    function: () => ({
                        title: document.title,
                        url: window.location.href,
                        content: document.body.innerText.substring(0, 3000)
                    })
                });
                
                const prompt = `Riassumi brevemente il contenuto principale di questa pagina web:\n\nTitolo: ${result.result.title}\nURL: ${result.result.url}\nContenuto: ${result.result.content}`;
                
                const response = await processWithGemini(prompt);
                
                // Invia il risultato al content script
                try {
                    await chrome.tabs.sendMessage(tab.id, {
                        type: 'showNotification',
                        data: {
                            type: 'result',
                            content: response
                        }
                    });
                } catch (msgError) {
                    // Fallback a notifica di sistema
                    chrome.notifications.create({
                        type: 'basic',
                        iconUrl: '../assets/icons/icon-48.png',
                        title: 'Analisi Pagina - Gemini AI',
                        message: response.substring(0, 200) + (response.length > 200 ? '...' : '')
                    });
                }
                
            } catch (error) {
                console.error('Page analysis error:', error);
                
                // Invia l'errore al content script
                try {
                    await chrome.tabs.sendMessage(tab.id, {
                        type: 'showNotification',
                        data: {
                            type: 'error',
                            content: error.message
                        }
                    });
                } catch (msgError) {
                    // Fallback a notifica di sistema
                    chrome.notifications.create({
                        type: 'basic',
                        iconUrl: '../assets/icons/icon-48.png',
                        title: 'Gemini AI Assistant',
                        message: 'Errore: ' + error.message
                    });
                }
            }
            break;
    }
});

// Funzione per processare con Gemini API
async function processWithGemini(prompt) {
    const settings = await getSettings();
    
    if (!settings.apiKey) {
        throw new Error('API Key non configurata. Apri le impostazioni per configurarla.');
    }
    
    const model = settings.model || 'gemini-1.5-flash';
    const maxTokens = settings.maxTokens || 1024;
    const temperature = settings.temperature || 0.7;
    
    // Mappa modelli per assicurare compatibilità
    const supportedModels = {
        'gemini-2.5-flash-preview-05-20': 'gemini-2.5-flash-preview-05-20',
        'gemini-2.5-pro-preview-05-06': 'gemini-2.5-pro-preview-05-06', 
        'gemini-2.0-flash-exp': 'gemini-2.0-flash-exp',
        'gemini-1.5-pro': 'gemini-1.5-pro',
        'gemini-1.5-flash': 'gemini-1.5-flash'
    };
    
    const modelName = supportedModels[model] || 'gemini-1.5-flash';
    
    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${modelName}:generateContent?key=${settings.apiKey}`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            contents: [{
                parts: [{
                    text: prompt
                }]
            }],
            generationConfig: {
                temperature: temperature,
                topK: 40,
                topP: 0.95,
                maxOutputTokens: maxTokens,
            }
        })
    });
    
    if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        if (response.status === 403) {
            throw new Error('API Key non valida o quota esaurita');
        } else if (response.status === 429) {
            throw new Error('Troppe richieste. Attendi qualche secondo');
        }
        throw new Error(`Errore API: ${response.status}`);
    }
    
    const data = await response.json();
    
    if (!data.candidates || !data.candidates[0] || !data.candidates[0].content) {
        throw new Error('Risposta non valida dall\'API');
    }
    
    return data.candidates[0].content.parts[0].text;
}

// Funzione helper per ottenere le impostazioni
async function getSettings() {
    return new Promise((resolve) => {
        chrome.storage.sync.get(['apiKey', 'model', 'maxTokens', 'temperature'], (result) => {
            resolve({
                apiKey: result.apiKey || '',
                model: result.model || 'gemini-1.5-flash',
                maxTokens: result.maxTokens || 1024,
                temperature: result.temperature || 0.7
            });
        });
    });
}

// Gestione messaggi dal popup e content script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.type === 'getPageContent') {
        // Ottieni contenuto pagina
        chrome.scripting.executeScript({
            target: { tabId: sender.tab.id },
            function: () => ({
                title: document.title,
                url: window.location.href,
                content: document.body.innerText.substring(0, 5000)
            })
        }).then(([result]) => {
            sendResponse(result.result);
        });
        return true; // Mantieni il canale aperto per risposta asincrona
    }
    
    if (request.type === 'processWithGemini') {
        // Gestisci richiesta di elaborazione dal content script
        processWithGemini(request.prompt)
            .then(result => {
                sendResponse({
                    success: true,
                    data: result
                });
            })
            .catch(error => {
                sendResponse({
                    success: false,
                    error: error.message
                });
            });
        return true; // Mantieni il canale aperto per risposta asincrona
    }
}); 