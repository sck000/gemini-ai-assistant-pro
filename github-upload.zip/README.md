# 🤖 Gemini AI Assistant Pro - v2.5

> **L'estensione Chrome più avanzata per Gemini AI con supporto completo per i modelli 2.5 e UI modernizzata**

![Version](https://img.shields.io/badge/version-2.5.0-blue.svg)
![Gemini](https://img.shields.io/badge/Gemini-2.5%20Pro%20%7C%202.5%20Flash%20%7C%202.0%20Flash-purple.svg)
![License](https://img.shields.io/badge/license-MIT-green.svg)
![UI](https://img.shields.io/badge/UI-Modernized%202025-orange.svg)

## ✨ Novità v2.5

### 🧠 **Gemini 2.5 Support**
- **Gemini 2.5 Pro Preview**: Il modello più intelligente con thinking capabilities
- **Gemini 2.5 Flash Preview**: Modello ibrido con performance ottimale 
- **Gemini 2.0 Flash**: Nuovo default bilanciato e affidabile
- **Token Limits**: Fino a 65k token output per risposte dettagliate

### 🎨 **Modern UI Design**
- **Glassmorphism Effects**: Interfaccia con effetti vetro moderni
- **Micro-Animations**: Feedback visivo fluido per ogni interazione
- **Responsive Design**: Layout ottimizzato per qualsiasi dimensione
- **Color Palette**: Sistema di colori premium con gradienti
- **Typography**: Font system SF Pro per leggibilità ottimale
- **Accessibility**: Compatibile WCAG AA per inclusività

## ✨ Caratteristiche Principali

### ⚡ Quick Assistant
- **Risposte rapide**: Chiedi qualsiasi cosa a Gemini
- **Riassunti istantanei**: Riassume pagine web con un click
- **Traduzione intelligente**: Traduci testo selezionato automaticamente
- **Spiegazioni semplici**: Ottieni spiegazioni chiare di concetti complessi

### ✍️ Writing Pro
- **Miglioramento testi**: Rendi i tuoi testi più chiari e fluidi
- **Cambio di stile**: Trasforma da casual a formale (e viceversa)
- **Correzione avanzata**: Grammatica e sintassi perfette
- **Espansione contenuti**: Aggiungi dettagli e argomentazioni

### 🔍 Research Companion
- **Analisi pagine web**: Analisi approfondita del contenuto
- **Fact-checking automatico**: Verifica l'accuratezza delle informazioni
- **Ricerca contestuale**: Ottieni informazioni correlate
- **Estrazione dati**: Estrae dati strutturati dalle pagine

## 🚀 Tecnologie Utilizzate

- **Gemini Nano Built-in**: Funziona offline senza API key (quando disponibile)
- **Modalità Web**: Utilizza gemini.google.com direttamente - **NESSUNA API KEY RICHIESTA!**
- **Gemini API Cloud**: Fallback per funzionalità avanzate
- **Manifest V3**: Estensione moderna e sicura
- **Context Menus**: Azioni rapide con tasto destro
- **Keyboard Shortcuts**: Scorciatoie personalizzabili

## 🆓 Usa SENZA API Key!

**NOVITÀ:** Puoi utilizzare l'intera estensione **completamente gratis** senza configurare nessuna API Key!

### 🎯 **Due Modalità Disponibili:**

#### 1. 🤖 **Gemini Nano (Offline)**
- ✅ **100% Offline** - funziona senza internet
- ✅ **Privacy totale** - dati mai inviati online  
- ✅ **Velocità istantanea** - nessuna latenza
- ✅ **Completamente gratuito**

#### 2. 🌐 **Modalità Web**
- ✅ **Nessuna API Key** necessaria
- ✅ **Accesso completo** al tuo abbonamento Pro
- ✅ **Automatico** - l'estensione gestisce tutto
- ✅ **Sempre aggiornato** con l'ultima versione

**📖 Guida Completa:** Vedi `NO-API-GUIDE.md` per istruzioni dettagliate!

## 👑 Per Utenti Gemini Pro

### 🎯 Vantaggi Esclusivi

Se hai un abbonamento **Gemini Pro**, puoi sbloccare tutto il potenziale dell'estensione:

#### ⚡ **Performance Superior**
- **Quota illimitata**: Nessun limite alle richieste giornaliere
- **Priorità di elaborazione**: Risposte più veloci
- **Token estesi**: Fino a 8192 token per risposte dettagliate

#### 🧠 **Modelli Avanzati**
- **Gemini Pro**: Modello standard ottimizzato
- **Gemini Pro Vision**: Analisi di immagini e contenuti multimediali
- **Gemini Ultra**: Il modello più potente per task complessi

#### 🔧 **Configurazione Pro**

1. **Nelle Impostazioni**, seleziona:
   - **Modello**: `Gemini Ultra` per massima potenza
   - **Token**: `8192` per risposte complete
   - **Temperatura**: `0.8-0.9` per creatività ottimale

2. **Usa la tua API Key Pro** associata all'abbonamento

3. **Sfrutta le funzionalità avanzate**:
   - Analisi documenti complessi
   - Traduzioni professionali
   - Ricerca approfondita

#### 📈 **Casi d'Uso Pro**
- **Research accademico**: Analisi approfondite di papers
- **Content creation**: Articoli lunghi e dettagliati
- **Business intelligence**: Report e analisi aziendali
- **Traduzioni professionali**: Documenti tecnici e legali

## 🛠️ Installazione

### Opzione 1: Installazione Manuale (Sviluppo)

1. **Clona o scarica il progetto**
   ```bash
   git clone <repository-url>
   cd gemini-ai-assistant-pro
   ```

2. **Crea le icone** (opzionale)
   - Aggiungi icone PNG nelle dimensioni: 16x16, 32x32, 48x48, 128x128
   - Salva in `assets/icons/` con nomi: `icon16.png`, `icon32.png`, etc.
   - Se non aggiungi icone, l'estensione userà emoji come placeholder

3. **Carica l'estensione in Chrome**
   - Apri Chrome e vai su `chrome://extensions/`
   - Abilita "Modalità sviluppatore" (in alto a destra)
   - Clicca "Carica estensione non compressa"
   - Seleziona la cartella `gemini-ai-assistant-pro`

### Opzione 2: Chrome Web Store (Coming Soon)
L'estensione sarà presto disponibile sul Chrome Web Store per un'installazione con un click.

## ⚙️ Configurazione

### 1. Prima Configurazione
Dopo l'installazione, l'estensione aprirà automaticamente la pagina delle impostazioni.

### 2. API Key Gemini (Raccomandata)
1. Vai su [Google AI Studio](https://makersuite.google.com/app/apikey)
2. Crea una nuova API Key (gratuita)
3. Copia e incolla la chiave nelle impostazioni dell'estensione
4. Clicca "Testa Connessione" per verificare

### 3. Gemini Nano (Opzionale)
Per usare Gemini offline:
1. Vai su `chrome://flags`
2. Cerca e abilita:
   - "Optimization Guide On Device"
   - "Prompt API for Gemini Nano"
3. Riavvia Chrome
4. Vai su `chrome://components`
5. Scarica "Optimization Guide On Device Model"

## 📚 Come Usare

### Scorciatoie da Tastiera
- **Ctrl+Shift+G** (Cmd+Shift+G su Mac): Apri Quick Assistant
- **Ctrl+Shift+A** (Cmd+Shift+A su Mac): Analizza pagina corrente
- **Esc**: Chiudi tutte le notifiche

### Menu Contestuale (Tasto Destro)
Seleziona qualsiasi testo e clicca tasto destro per accedere a:
- 💡 Spiega selezione
- 🌍 Traduci in italiano
- 📋 Riassumi selezione
- ✨ Migliora testo
- 🎩 Rendi formale
- 😊 Rendi casual
- ✅ Fact-check
- 📊 Analizza pagina

### Popup dell'Estensione
Clicca sull'icona dell'estensione per accedere a tre sezioni:

#### ⚡ Quick Assistant
- Input libero per domande generali
- Pulsanti rapidi per azioni comuni
- Riassunti automatici delle pagine

#### ✍️ Writing Pro
- Selettore modalità di scrittura
- Incolla testo dagli appunti
- Miglioramento istantaneo

#### 🔍 Research Companion
- Strumenti di analisi avanzata
- Input per domande specifiche
- Estrazione dati strutturati

### Pulsante Fluttuante
Un pulsante 🤖 appare in basso a destra su ogni pagina per accesso rapido.

## ⚡ Prestazioni e Privacy

### Gemini Nano (Built-in)
- ✅ **Offline**: Funziona senza internet
- ✅ **Privacy**: Dati mai inviati online
- ✅ **Velocità**: Risposte istantanee
- ✅ **Gratuito**: Nessun costo API

### Gemini API (Cloud)
- ⚠️ **Online**: Richiede connessione internet
- ⚠️ **Privacy**: Dati inviati a Google (criptati)
- ✅ **Potenza**: Modelli più avanzati
- ⚠️ **Costi**: Uso gratuito limitato

## 🔧 Personalizzazione

### Impostazioni Avanzate
- **Creatività**: Regola la creatività delle risposte (0-1)
- **Lunghezza**: Controlla la lunghezza massima delle risposte
- **Lingua**: Imposta la lingua predefinita
- **Provider**: Scegli tra Nano e API Cloud

### Sviluppo e Personalizzazione
Il codice è completamente open source e personalizzabile:

```javascript
// Esempio: Personalizza prompt in popup/popup.js
const prompts = {
    improve: 'Il tuo prompt personalizzato qui...',
    // ... altri prompt
};
```

## 🐛 Risoluzione Problemi

### Problemi Comuni

**❌ "API Key non configurata"**
- Soluzione: Aggiungi una API Key valida nelle impostazioni

**❌ "Gemini Nano non disponibile"**
- Soluzione: Segui i passaggi per abilitare Gemini Nano
- Alternativa: Usa l'API Cloud con una API Key

**❌ Estensione non appare nel menu contestuale**
- Soluzione: Ricarica la pagina o riavvia Chrome

**❌ Popup non si apre**
- Soluzione: Controlla che l'estensione sia abilitata in `chrome://extensions/`

### Debug
Apri DevTools (F12) e controlla la console per errori dettagliati.

## 🤝 Contribuire

Questo progetto è open source! Contribuisci con:

1. **Bug Reports**: Segnala problemi nelle Issues
2. **Feature Requests**: Proponi nuove funzionalità
3. **Pull Requests**: Contribuisci con codice
4. **Traduzioni**: Aiuta a tradurre l'interfaccia

### Sviluppo Locale

```bash
# Clona il repository
git clone <repository-url>
cd gemini-ai-assistant-pro

# Carica l'estensione in Chrome per testare
# Modifica il codice e ricarica l'estensione per vedere i cambiamenti
```

## 📄 Licenza

Questo progetto è rilasciato sotto licenza MIT. Vedi il file `LICENSE` per dettagli.

## 🙏 Ringraziamenti

- **Google Gemini Team**: Per l'incredibile tecnologia AI
- **Chrome Extensions Team**: Per le API potenti e flessibili
- **Community Open Source**: Per feedback e contributi

## 📞 Supporto

- **Issues**: [GitHub Issues](link-to-issues)
- **Email**: [support@esempio.com](mailto:support@esempio.com)
- **Documentazione**: [Wiki del progetto](link-to-wiki)

---

**🌟 Ti piace questa estensione? Lascia una stella su GitHub e condividila con i tuoi amici!**

![Gemini AI Assistant Pro Screenshot](screenshot.png)

> **Nota**: Questa estensione non è affiliata ufficialmente con Google. Gemini è un marchio di Google LLC. 