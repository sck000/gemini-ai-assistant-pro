const sharp = require('sharp');
const fs = require('fs');
const path = require('path');

const sizes = [16, 32, 48, 128];
const inputSvg = path.join(__dirname, '../assets/icons/icon128.svg');
const outputDir = path.join(__dirname, '../assets/icons');

async function generateIcons() {
  console.log('🎨 Generating PNG icons from SVG...');
  
  if (!fs.existsSync(inputSvg)) {
    console.error('❌ SVG icon not found:', inputSvg);
    process.exit(1);
  }

  for (const size of sizes) {
    try {
      const outputPath = path.join(outputDir, `icon${size}.png`);
      
      await sharp(inputSvg)
        .resize(size, size)
        .png()
        .toFile(outputPath);
      
      console.log(`✅ Generated: icon${size}.png`);
    } catch (error) {
      console.error(`❌ Error generating icon${size}.png:`, error.message);
    }
  }

  // Generate store icon (same as 128x128)
  try {
    const storeIconPath = path.join(outputDir, 'store-icon.png');
    await sharp(inputSvg)
      .resize(128, 128)
      .png()
      .toFile(storeIconPath);
    
    console.log('✅ Generated: store-icon.png');
  } catch (error) {
    console.error('❌ Error generating store-icon.png:', error.message);
  }

  console.log('🎉 Icon generation complete!');
}

if (require.main === module) {
  generateIcons().catch(console.error);
}

module.exports = { generateIcons }; 