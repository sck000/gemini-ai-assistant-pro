const fs = require('fs');
const path = require('path');

function validateManifest() {
  console.log('🔍 Validating manifest.json...');
  
  const manifestPath = path.join(__dirname, '../manifest.json');
  
  if (!fs.existsSync(manifestPath)) {
    console.error('❌ manifest.json not found');
    process.exit(1);
  }

  let manifest;
  try {
    manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
  } catch (error) {
    console.error('❌ Invalid JSON in manifest.json:', error.message);
    process.exit(1);
  }

  // Required fields validation
  const requiredFields = ['manifest_version', 'name', 'version', 'description'];
  const missingFields = requiredFields.filter(field => !manifest[field]);
  
  if (missingFields.length > 0) {
    console.error('❌ Missing required fields:', missingFields.join(', '));
    process.exit(1);
  }

  // Manifest V3 validation
  if (manifest.manifest_version !== 3) {
    console.error('❌ Must use manifest_version 3');
    process.exit(1);
  }

  // Version format validation
  const versionRegex = /^\d+\.\d+\.\d+$/;
  if (!versionRegex.test(manifest.version)) {
    console.error('❌ Invalid version format. Use x.y.z format');
    process.exit(1);
  }

  // i18n validation
  if (manifest.name.startsWith('__MSG_') || manifest.description.startsWith('__MSG_')) {
    if (!manifest.default_locale) {
      console.error('❌ default_locale required when using i18n messages');
      process.exit(1);
    }
    
    // Check if locale files exist
    const localesDir = path.join(__dirname, '../_locales');
    if (!fs.existsSync(localesDir)) {
      console.error('❌ _locales directory not found');
      process.exit(1);
    }
    
    const defaultLocaleDir = path.join(localesDir, manifest.default_locale);
    if (!fs.existsSync(defaultLocaleDir)) {
      console.error(`❌ Default locale directory not found: ${manifest.default_locale}`);
      process.exit(1);
    }
    
    const messagesFile = path.join(defaultLocaleDir, 'messages.json');
    if (!fs.existsSync(messagesFile)) {
      console.error(`❌ messages.json not found in ${manifest.default_locale} locale`);
      process.exit(1);
    }
  }

  // Icons validation
  if (manifest.icons) {
    for (const [size, iconPath] of Object.entries(manifest.icons)) {
      const fullPath = path.join(__dirname, '..', iconPath);
      if (!fs.existsSync(fullPath)) {
        console.warn(`⚠️  Icon not found: ${iconPath} (${size}x${size})`);
      }
    }
  }

  // Permissions validation
  if (manifest.permissions) {
    const validPermissions = [
      'activeTab', 'alarms', 'background', 'bookmarks', 'contextMenus',
      'cookies', 'declarativeContent', 'downloads', 'fontSettings',
      'geolocation', 'history', 'identity', 'idle', 'management',
      'nativeMessaging', 'notifications', 'pageCapture', 'power',
      'privacy', 'proxy', 'scripting', 'search', 'storage', 'system.cpu',
      'system.display', 'system.memory', 'system.storage', 'tabCapture',
      'tabs', 'topSites', 'tts', 'ttsEngine', 'unlimitedStorage',
      'webNavigation', 'webRequest', 'webRequestBlocking'
    ];
    
    const invalidPermissions = manifest.permissions.filter(
      perm => !validPermissions.includes(perm) && !perm.startsWith('http')
    );
    
    if (invalidPermissions.length > 0) {
      console.warn('⚠️  Potentially invalid permissions:', invalidPermissions.join(', '));
    }
  }

  console.log('✅ Manifest validation passed!');
  console.log(`📦 Extension: ${manifest.name}`);
  console.log(`🏷️  Version: ${manifest.version}`);
  console.log(`🌍 Default locale: ${manifest.default_locale || 'en'}`);
  console.log(`🔑 Permissions: ${manifest.permissions?.length || 0}`);
}

if (require.main === module) {
  validateManifest();
}

module.exports = { validateManifest }; 