// Content Script per Gemini AI Assistant Pro

class GeminiContentScript {
    constructor() {
        this.isInjected = false;
        this.selectedText = '';
        this.init();
    }

    init() {
        // Evita doppia iniezione
        if (window.geminiAssistantInjected) {
            return;
        }
        window.geminiAssistantInjected = true;

        this.setupEventListeners();
        this.setupKeyboardShortcuts();
        console.log('Gemini AI Assistant Pro - Content script loaded');
    }

    setupEventListeners() {
        // Text selection tracking
        document.addEventListener('mouseup', (e) => {
            setTimeout(() => {
                this.updateSelectedText();
                this.handleTextSelection(e);
            }, 100); // Piccolo delay per assicurarsi che la selezione sia completa
        });

        document.addEventListener('keyup', (e) => {
            setTimeout(() => {
                this.updateSelectedText();
                this.handleTextSelection(e);
            }, 100);
        });

        // Hide button when clicking elsewhere
        document.addEventListener('mousedown', (e) => {
            // Se non si clicca sul pulsante floating, nascondilo
            if (!e.target.closest('#gemini-floating-btn')) {
                this.hideFloatingButton();
            }
        });

        // Hide button when selection changes
        document.addEventListener('selectionchange', () => {
            setTimeout(() => {
                const selectedText = this.getSelectedText();
                if (!selectedText || selectedText.length === 0) {
                    this.hideFloatingButton();
                }
            }, 100);
        });

        // Message listener from background script
        chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
            this.handleMessage(message, sender, sendResponse);
            return true;
        });

        // Prevent conflicts with existing notification elements
        this.cleanupPreviousNotifications();
    }

    setupKeyboardShortcuts() {
        document.addEventListener('keydown', (e) => {
            // Ctrl+Shift+G (Cmd+Shift+G on Mac) - Quick Assistant
            if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key === 'G') {
                e.preventDefault();
                this.openQuickAssistant();
            }

            // Ctrl+Shift+A (Cmd+Shift+A on Mac) - Analyze Page
            if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key === 'A') {
                e.preventDefault();
                this.analyzePage();
            }

            // Escape - Close notifications
            if (e.key === 'Escape') {
                this.closeAllNotifications();
                this.hideFloatingButton();
            }
        });
    }

    async openQuickAssistant() {
        const selectedText = this.getSelectedText();
        
        if (selectedText) {
            // If text is selected, show quick actions menu
            this.showQuickActionsMenu(selectedText);
        } else {
            // Otherwise, show input dialog
            this.showInputDialog();
        }
    }

    showQuickActionsMenu(text) {
        this.closeAllNotifications();
        
        // Usa la lingua del browser invece di chrome.i18n che non è disponibile nei content scripts
        const currentLanguage = navigator.language ? navigator.language.substring(0, 2) : 'it';
        
        const labels = currentLanguage === 'it' ? {
            title: 'Azioni AI',
            selectedText: 'Testo selezionato:',
            explain: { title: 'Spiega', desc: 'Spiegazione semplice e chiara' },
            translate: { title: 'Traduci', desc: 'Traduzione in italiano' },
            summarize: { title: 'Riassumi', desc: 'Riassunto conciso' },
            improve: { title: 'Migliora', desc: 'Miglioramento del testo' },
            factcheck: { title: 'Fact-check', desc: 'Verifica informazioni' }
        } : {
            title: 'AI Actions',
            selectedText: 'Selected text:',
            explain: { title: 'Explain', desc: 'Simple and clear explanation' },
            translate: { title: 'Translate', desc: 'Translation to English' },
            summarize: { title: 'Summarize', desc: 'Concise summary' },
            improve: { title: 'Improve', desc: 'Text improvement' },
            factcheck: { title: 'Fact-check', desc: 'Information verification' }
        };

        const menu = document.createElement('div');
        menu.id = 'gemini-quick-menu';
        menu.style.cssText = `
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: white;
            border-radius: 16px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
            z-index: 10001;
            padding: 20px;
            min-width: 300px;
            max-width: 400px;
            font-family: 'Segoe UI', sans-serif;
        `;

        menu.innerHTML = `
            <div style="margin-bottom: 16px; padding-bottom: 12px; border-bottom: 1px solid #eee;">
                <h3 style="margin: 0; color: #333; font-size: 18px; display: flex; align-items: center; gap: 8px;">
                    <span>🤖</span>
                    ${labels.title}
                    <button id="close-menu-btn" 
                            style="margin-left: auto; background: none; border: none; font-size: 20px; cursor: pointer; color: #999;">×</button>
                </h3>
                <p style="margin: 8px 0 0 0; color: #666; font-size: 13px;">
                    ${labels.selectedText} "${text.substring(0, 50)}${text.length > 50 ? '...' : ''}"
                </p>
            </div>
            
            <div style="display: grid; gap: 8px;">
                <button class="menu-action" data-action="explain">
                    <span>💡</span>
                    <div>
                        <strong>${labels.explain.title}</strong>
                        <small>${labels.explain.desc}</small>
                    </div>
                </button>
                
                <button class="menu-action" data-action="translate">
                    <span>🌍</span>
                    <div>
                        <strong>${labels.translate.title}</strong>
                        <small>${labels.translate.desc}</small>
                    </div>
                </button>
                
                <button class="menu-action" data-action="summarize">
                    <span>📋</span>
                    <div>
                        <strong>${labels.summarize.title}</strong>
                        <small>${labels.summarize.desc}</small>
                    </div>
                </button>
                
                <button class="menu-action" data-action="improve">
                    <span>✨</span>
                    <div>
                        <strong>${labels.improve.title}</strong>
                        <small>${labels.improve.desc}</small>
                    </div>
                </button>
                
                <button class="menu-action" data-action="factcheck">
                    <span>✅</span>
                    <div>
                        <strong>${labels.factcheck.title}</strong>
                        <small>${labels.factcheck.desc}</small>
                    </div>
                </button>
            </div>`;

        // Add styles for menu actions
        const style = document.createElement('style');
        style.textContent = `
            .menu-action {
                display: flex;
                align-items: center;
                gap: 12px;
                padding: 12px;
                border: 1px solid #e1e5e9;
                border-radius: 8px;
                background: white;
                cursor: pointer;
                transition: all 0.2s ease;
                font-family: inherit;
                text-align: left;
            }
            .menu-action:hover {
                background: #f8f9fa;
                border-color: #667eea;
                transform: translateX(4px);
            }
            .menu-action span {
                font-size: 18px;
                flex-shrink: 0;
            }
            .menu-action strong {
                display: block;
                color: #333;
                font-size: 14px;
            }
            .menu-action small {
                display: block;
                color: #666;
                font-size: 12px;
                margin-top: 2px;
            }
        `;
        document.head.appendChild(style);

        // Add backdrop
        const backdrop = this.createBackdrop();
        document.body.appendChild(backdrop);
        document.body.appendChild(menu);

        // Close menu function
        const closeMenu = () => {
            menu.remove();
            backdrop.remove();
            style.remove();
        };

        // Handle close button
        const closeBtn = menu.querySelector('#close-menu-btn');
        closeBtn.addEventListener('click', closeMenu);

        // Handle backdrop click to close
        backdrop.addEventListener('click', closeMenu);

        // Prevent menu click from closing
        menu.addEventListener('click', (e) => {
            e.stopPropagation();
        });

        // Handle ESC key to close
        const handleEscKey = (e) => {
            if (e.key === 'Escape') {
                closeMenu();
                document.removeEventListener('keydown', handleEscKey);
            }
        };
        document.addEventListener('keydown', handleEscKey);

        // Add event listeners for actions
        menu.querySelectorAll('.menu-action').forEach(btn => {
            btn.addEventListener('click', async (e) => {
                const action = e.currentTarget.dataset.action;
                closeMenu();
                document.removeEventListener('keydown', handleEscKey);
                await this.processAction(action, text);
            });
        });
    }

    showInputDialog() {
        this.closeAllNotifications();

        const dialog = document.createElement('div');
        dialog.id = 'gemini-input-dialog';
        dialog.style.cssText = `
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: white;
            border-radius: 16px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
            z-index: 10001;
            padding: 24px;
            min-width: 400px;
            max-width: 500px;
            font-family: 'Segoe UI', sans-serif;
        `;

        dialog.innerHTML = `
            <div style="margin-bottom: 20px; display: flex; align-items: center; gap: 12px;">
                <span style="font-size: 24px;">🤖</span>
                <h3 style="margin: 0; color: #333; flex: 1;">Gemini AI Assistant</h3>
                <button id="close-dialog-btn" 
                        style="background: none; border: none; font-size: 20px; cursor: pointer; color: #999;">×</button>
            </div>
            
            <div style="margin-bottom: 16px;">
                <textarea id="gemini-input" placeholder="Chiedi qualsiasi cosa a Gemini..." 
                          style="width: 100%; height: 80px; padding: 12px; border: 2px solid #e1e5e9; border-radius: 8px; font-family: inherit; font-size: 14px; resize: vertical;">
                </textarea>
            </div>
            
            <div style="display: flex; gap: 12px; justify-content: flex-end;">
                <button id="cancel-dialog-btn" 
                        style="padding: 8px 16px; border: 1px solid #e1e5e9; border-radius: 6px; background: white; cursor: pointer; font-size: 14px;">
                    Annulla
                </button>
                <button id="gemini-send-btn" 
                        style="padding: 8px 20px; background: linear-gradient(45deg, #667eea, #764ba2); color: white; border: none; border-radius: 6px; cursor: pointer; font-size: 14px; font-weight: 600;">
                    <span>🚀</span> Invia
                </button>
            </div>
        `;

        const backdrop = this.createBackdrop();
        document.body.appendChild(backdrop);
        document.body.appendChild(dialog);

        // Focus on input
        const input = dialog.querySelector('#gemini-input');
        input.focus();

        // Close dialog function
        const closeDialog = () => {
            dialog.remove();
            backdrop.remove();
        };

        // Handle close buttons
        const closeBtn = dialog.querySelector('#close-dialog-btn');
        const cancelBtn = dialog.querySelector('#cancel-dialog-btn');
        
        closeBtn.addEventListener('click', closeDialog);
        cancelBtn.addEventListener('click', closeDialog);

        // Handle backdrop click to close
        backdrop.addEventListener('click', closeDialog);

        // Prevent dialog click from closing
        dialog.addEventListener('click', (e) => {
            e.stopPropagation();
        });

        // Handle ESC key to close
        const handleEscKey = (e) => {
            if (e.key === 'Escape') {
                closeDialog();
                document.removeEventListener('keydown', handleEscKey);
            }
        };
        document.addEventListener('keydown', handleEscKey);

        // Handle send
        const sendBtn = dialog.querySelector('#gemini-send-btn');
        const handleSend = async () => {
            const prompt = input.value.trim();
            if (!prompt) return;

            closeDialog();
            await this.processPrompt(prompt);
            document.removeEventListener('keydown', handleEscKey);
        };

        sendBtn.addEventListener('click', handleSend);
        input.addEventListener('keydown', (e) => {
            if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
                e.preventDefault();
                handleSend();
            }
        });
    }

    async processAction(action, text) {
        // Get localized prompts based on the extension's current language
        const currentLanguage = navigator.language ? navigator.language.substring(0, 2) : 'it';
        
        let prompts;
        
        if (currentLanguage === 'it') {
            prompts = {
                explain: `Spiega in modo semplice e chiaro questo testo:\n\n${text}`,
                translate: `Traduci questo testo in italiano:\n\n${text}`,
                summarize: `Riassumi brevemente questo testo:\n\n${text}`,
                improve: `Migliora questo testo rendendolo più chiaro e ben scritto:\n\n${text}`,
                factcheck: `Analizza questa affermazione e fornisci un fact-check:\n\n${text}`
            };
        } else {
            // Default to English
            prompts = {
                explain: `Explain this text in a simple and clear way:\n\n${text}`,
                translate: `Translate this text to English:\n\n${text}`,
                summarize: `Briefly summarize this text:\n\n${text}`,
                improve: `Improve this text making it clearer and better written:\n\n${text}`,
                factcheck: `Analyze this statement and provide a fact-check:\n\n${text}`
            };
        }

        const prompt = prompts[action];
        if (prompt) {
            await this.processPrompt(prompt);
        }
    }

    async processPrompt(prompt) {
        try {
            // Show loading
            this.showLoadingNotification();

            // Send to background script for processing
            const response = await chrome.runtime.sendMessage({
                type: 'processWithGemini',
                prompt: prompt
            });

            this.closeAllNotifications();

            if (response.success) {
                this.showResultNotification(response.data);
            } else {
                this.showErrorNotification(response.error || 'Errore sconosciuto');
            }

        } catch (error) {
            this.closeAllNotifications();
            this.showErrorNotification(error.message);
        }
    }

    async analyzePage() {
        try {
            const currentLanguage = navigator.language ? navigator.language.substring(0, 2) : 'it';
            
            const loadingMessage = currentLanguage === 'it' ? 
                'Analizzando la pagina...' : 'Analyzing the page...';
            
            this.showLoadingNotification(loadingMessage);

            const context = {
                title: document.title,
                url: window.location.href,
                content: document.body.innerText.substring(0, 5000)
            };

            const prompt = currentLanguage === 'it' ?
                `Analizza questa pagina web e fornisci:
1. Argomento principale
2. Punti chiave (massimo 5)
3. Credibilità delle informazioni
4. Riassunto esecutivo

URL: ${context.url}
Titolo: ${context.title}
Contenuto: ${context.content}...` :
                `Analyze this web page and provide:
1. Main topic
2. Key points (maximum 5)
3. Information credibility
4. Executive summary

URL: ${context.url}
Title: ${context.title}
Content: ${context.content}...`;

            await this.processPrompt(prompt);

        } catch (error) {
            this.closeAllNotifications();
            this.showErrorNotification(error.message);
        }
    }

    showLoadingNotification(message = 'Gemini sta elaborando...') {
        this.closeAllNotifications();

        const notification = document.createElement('div');
        notification.id = 'gemini-loading';
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: linear-gradient(45deg, #667eea, #764ba2);
            color: white;
            padding: 16px 20px;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.3);
            z-index: 10000;
            font-family: 'Segoe UI', sans-serif;
            font-size: 14px;
            max-width: 300px;
            backdrop-filter: blur(10px);
        `;

        notification.innerHTML = `
            <div style="display: flex; align-items: center; gap: 10px;">
                <div style="width: 20px; height: 20px; border: 2px solid rgba(255,255,255,0.3); border-top: 2px solid white; border-radius: 50%; animation: spin 1s linear infinite;"></div>
                <span>${message}</span>
            </div>
            <style>
                @keyframes spin { to { transform: rotate(360deg); } }
            </style>
        `;

        document.body.appendChild(notification);
    }

    showResultNotification(result) {
        this.closeAllNotifications();

        const notification = document.createElement('div');
        notification.id = 'gemini-result';
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: white;
            border: 1px solid #e1e5e9;
            border-radius: 12px;
            box-shadow: 0 8px 32px rgba(0,0,0,0.12);
            z-index: 10000;
            font-family: 'Segoe UI', sans-serif;
            font-size: 14px;
            max-width: 400px;
            max-height: 500px;
            overflow: hidden;
        `;

        notification.innerHTML = `
            <div style="padding: 16px 20px; border-bottom: 1px solid #eee; display: flex; align-items: center; gap: 8px; background: linear-gradient(45deg, #667eea, #764ba2); color: white;">
                <span>🤖</span>
                <strong>Gemini AI</strong>
                <button id="close-result-btn" 
                        style="margin-left: auto; background: none; border: none; color: white; cursor: pointer; font-size: 16px;">×</button>
            </div>
            <div style="padding: 16px 20px; line-height: 1.5; max-height: 300px; overflow-y: auto;">
                ${result.replace(/\n/g, '<br>').replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')}
            </div>
            <div style="padding: 12px 20px; border-top: 1px solid #eee; display: flex; gap: 8px; background: #f8f9fa;">
                <button id="copy-result-btn" 
                        style="flex: 1; background: #667eea; color: white; border: none; padding: 6px 12px; border-radius: 6px; cursor: pointer; font-size: 12px; font-weight: 600;">
                    📋 Copia
                </button>
                <button id="close-result-btn2" 
                        style="background: #e9ecef; border: none; padding: 6px 12px; border-radius: 6px; cursor: pointer; font-size: 12px;">
                    Chiudi
                </button>
            </div>
        `;

        document.body.appendChild(notification);

        // Add event listeners
        const closeBtn = notification.querySelector('#close-result-btn');
        const closeBtn2 = notification.querySelector('#close-result-btn2');
        const copyBtn = notification.querySelector('#copy-result-btn');

        const closeNotification = () => {
            notification.remove();
        };

        closeBtn.addEventListener('click', closeNotification);
        closeBtn2.addEventListener('click', closeNotification);
        
        copyBtn.addEventListener('click', () => {
            navigator.clipboard.writeText(result).then(() => {
                copyBtn.textContent = '✅ Copiato!';
                setTimeout(() => {
                    copyBtn.innerHTML = '📋 Copia';
                }, 2000);
            }).catch(err => {
                console.error('Errore nella copia:', err);
            });
        });

        // Auto-remove after 15 seconds
        setTimeout(() => {
            if (notification.parentNode) {
                notification.remove();
            }
        }, 15000);
    }

    showErrorNotification(error) {
        this.closeAllNotifications();

        const notification = document.createElement('div');
        notification.id = 'gemini-error';
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: #f44336;
            color: white;
            padding: 16px 20px;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(244, 67, 54, 0.3);
            z-index: 10000;
            font-family: 'Segoe UI', sans-serif;
            font-size: 14px;
            max-width: 300px;
        `;

        notification.innerHTML = `
            <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 8px;">
                <span>⚠️</span>
                <strong>Errore</strong>
                <button id="close-error-btn" 
                        style="margin-left: auto; background: none; border: none; color: white; cursor: pointer; font-size: 16px;">×</button>
            </div>
            <div style="font-size: 13px; opacity: 0.9;">${error}</div>
        `;

        document.body.appendChild(notification);

        // Add event listener for close button
        const closeBtn = notification.querySelector('#close-error-btn');
        closeBtn.addEventListener('click', () => {
            notification.remove();
        });

        // Auto-remove after 5 seconds
        setTimeout(() => {
            if (notification.parentNode) {
                notification.remove();
            }
        }, 5000);
    }

    createBackdrop() {
        const backdrop = document.createElement('div');
        backdrop.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.3);
            z-index: 10000;
            backdrop-filter: blur(2px);
        `;

        // Note: backdrop click handling is now managed in specific dialogs
        return backdrop;
    }

    closeAllNotifications() {
        const notifications = [
            'gemini-quick-menu',
            'gemini-input-dialog',
            'gemini-loading',
            'gemini-result',
            'gemini-error'
        ];

        notifications.forEach(id => {
            const element = document.getElementById(id);
            if (element) {
                element.remove();
            }
        });

        // Remove backdrops
        document.querySelectorAll('[style*="backdrop-filter: blur"]').forEach(el => {
            if (el.style.position === 'fixed' && el.style.zIndex === '10000') {
                el.remove();
            }
        });
    }

    cleanupPreviousNotifications() {
        // Clean up any existing notifications on page load
        this.closeAllNotifications();
    }

    updateSelectedText() {
        this.selectedText = window.getSelection().toString().trim();
    }

    getSelectedText() {
        return window.getSelection().toString().trim();
    }

    handleMessage(message, sender, sendResponse) {
        switch (message.type) {
            case 'getSelectedText':
                sendResponse(this.getSelectedText());
                break;
            case 'showLoading':
                this.showLoadingNotification(message.data.message);
                sendResponse({ success: true });
                break;
            case 'showNotification':
                if (message.data.type === 'result') {
                    this.showResultNotification(message.data.content);
                } else if (message.data.type === 'error') {
                    this.showErrorNotification(message.data.content);
                }
                sendResponse({ success: true });
                break;
            default:
                sendResponse({ success: false, error: 'Unknown message type' });
        }
    }

    handleTextSelection(e) {
        const selectedText = this.getSelectedText();
        
        if (selectedText && selectedText.length > 0) {
            // Mostra il pulsante floating vicino alla selezione
            this.showFloatingButton(e);
        } else {
            // Nascondi il pulsante se non c'è testo selezionato
            this.hideFloatingButton();
        }
    }

    showFloatingButton(e) {
        // Rimuovi il pulsante esistente se presente
        this.hideFloatingButton();

        const selection = window.getSelection();
        if (selection.rangeCount === 0) return;

        const range = selection.getRangeAt(0);
        const rect = range.getBoundingClientRect();

        const floatingBtn = document.createElement('div');
        floatingBtn.id = 'gemini-floating-btn';
        floatingBtn.innerHTML = '🤖';
        
        // Calcola la posizione ottimale
        const scrollY = window.scrollY;
        const scrollX = window.scrollX;
        let top = rect.bottom + scrollY + 10;
        let left = rect.left + scrollX + (rect.width / 2) - 28; // 28 = metà della larghezza del pulsante

        // Assicurati che il pulsante rimanga nella viewport
        const viewportWidth = window.innerWidth;
        const viewportHeight = window.innerHeight;
        
        if (left < 10) left = 10;
        if (left > viewportWidth - 66) left = viewportWidth - 66; // 56 + 10 margin
        
        // Se il pulsante uscirebbe dalla viewport in basso, mettilo sopra la selezione
        if (top + 56 > scrollY + viewportHeight) {
            top = rect.top + scrollY - 66; // 56 + 10 margin
        }

        floatingBtn.style.cssText = `
            position: absolute;
            top: ${top}px;
            left: ${left}px;
            width: 56px;
            height: 56px;
            background: linear-gradient(45deg, #667eea, #764ba2);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            cursor: pointer;
            z-index: 9999;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
            transition: all 0.3s ease;
            border: none;
            user-select: none;
            animation: gemini-fade-in 0.3s ease-out;
        `;

        // Aggiungi CSS per l'animazione
        if (!document.getElementById('gemini-floating-styles')) {
            const style = document.createElement('style');
            style.id = 'gemini-floating-styles';
            style.textContent = `
                @keyframes gemini-fade-in {
                    from {
                        opacity: 0;
                        transform: scale(0.8);
                    }
                    to {
                        opacity: 1;
                        transform: scale(1);
                    }
                }
                
                #gemini-floating-btn:hover {
                    transform: scale(1.1);
                    box-shadow: 0 6px 20px rgba(102, 126, 234, 0.4);
                }
            `;
            document.head.appendChild(style);
        }

        // Click handler
        floatingBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            this.openQuickAssistant();
        });

        // Tooltip
        floatingBtn.title = 'Gemini AI Assistant - Azioni per il testo selezionato';

        document.body.appendChild(floatingBtn);

        // Auto-hide dopo 5 secondi se non usato
        setTimeout(() => {
            if (document.getElementById('gemini-floating-btn') === floatingBtn) {
                this.hideFloatingButton();
            }
        }, 5000);
    }

    hideFloatingButton() {
        const existingBtn = document.getElementById('gemini-floating-btn');
        if (existingBtn) {
            // Aggiungi CSS per l'animazione di uscita se non presente
            if (!document.querySelector('style[data-gemini-fade-out]')) {
                const style = document.createElement('style');
                style.setAttribute('data-gemini-fade-out', 'true');
                style.textContent = `
                    @keyframes gemini-fade-out {
                        from {
                            opacity: 1;
                            transform: scale(1);
                        }
                        to {
                            opacity: 0;
                            transform: scale(0.8);
                        }
                    }
                `;
                document.head.appendChild(style);
            }
            
            existingBtn.style.animation = 'gemini-fade-out 0.2s ease-in forwards';
            setTimeout(() => {
                if (existingBtn.parentNode) {
                    existingBtn.remove();
                }
            }, 200);
        }
    }
}

// Initialize content script
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        new GeminiContentScript();
    });
} else {
    new GeminiContentScript();
} 