// Gemini Web Bridge - Content Script per gemini.google.com
class GeminiWebBridge {
    constructor() {
        this.isGeminiSite = window.location.hostname.includes('gemini.google.com');
        this.isReady = false;
        this.init();
    }

    init() {
        if (!this.isGeminiSite) return;
        
        console.log('🤖 Gemini Web Bridge attivato');
        this.waitForInterface();
        this.setupMessageListener();
    }

    async waitForInterface() {
        // Aspetta che l'interfaccia di Gemini sia caricata
        const maxAttempts = 30;
        let attempts = 0;

        const checkInterval = setInterval(() => {
            const inputArea = this.findInputArea();
            const sendButton = this.findSendButton();

            if (inputArea && sendButton) {
                this.isReady = true;
                clearInterval(checkInterval);
                console.log('✅ Interfaccia Gemini pronta');
                this.notifyReady();
            }

            attempts++;
            if (attempts >= maxAttempts) {
                clearInterval(checkInterval);
                console.log('❌ Timeout: Interfaccia Gemini non trovata');
            }
        }, 1000);
    }

    findInputArea() {
        // Cerca l'area di input di Gemini (selettori potrebbero cambiare)
        const selectors = [
            'div[contenteditable="true"]',
            'textarea[placeholder*="Enter a prompt"]',
            'textarea[placeholder*="Message"]',
            '[data-testid="textbox"]',
            '.ql-editor',
            '[role="textbox"]'
        ];

        for (const selector of selectors) {
            const element = document.querySelector(selector);
            if (element && this.isVisibleAndInteractable(element)) {
                return element;
            }
        }
        return null;
    }

    findSendButton() {
        // Cerca il pulsante di invio
        const selectors = [
            'button[aria-label*="Send"]',
            'button[aria-label*="Submit"]',
            'button[data-testid="send"]',
            'button[type="submit"]',
            '[aria-label*="send" i]'
        ];

        for (const selector of selectors) {
            const element = document.querySelector(selector);
            if (element && this.isVisibleAndInteractable(element)) {
                return element;
            }
        }
        return null;
    }

    isVisibleAndInteractable(element) {
        const style = window.getComputedStyle(element);
        return style.display !== 'none' && 
               style.visibility !== 'hidden' && 
               element.offsetParent !== null;
    }

    setupMessageListener() {
        chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
            if (message.type === 'gemini-web-query') {
                this.handleWebQuery(message.prompt)
                    .then(response => sendResponse({ success: true, data: response }))
                    .catch(error => sendResponse({ success: false, error: error.message }));
                return true; // Keep channel open for async response
            }
            
            if (message.type === 'gemini-web-status') {
                sendResponse({ 
                    success: true, 
                    ready: this.isReady,
                    url: window.location.href
                });
            }
        });
    }

    async handleWebQuery(prompt) {
        if (!this.isReady) {
            throw new Error('Interfaccia Gemini non pronta. Assicurati di essere su gemini.google.com');
        }

        try {
            // 1. Trova e pulisci l'area di input
            const inputArea = this.findInputArea();
            if (!inputArea) {
                throw new Error('Area di input non trovata');
            }

            // 2. Inserisci il prompt
            await this.insertText(inputArea, prompt);

            // 3. Clicca il pulsante di invio
            const sendButton = this.findSendButton();
            if (!sendButton) {
                throw new Error('Pulsante di invio non trovato');
            }

            sendButton.click();

            // 4. Aspetta la risposta
            const response = await this.waitForResponse();
            
            return response;

        } catch (error) {
            console.error('Errore nell\'invio query:', error);
            throw error;
        }
    }

    async insertText(element, text) {
        // Pulisce il campo
        element.focus();
        
        if (element.tagName === 'TEXTAREA' || element.tagName === 'INPUT') {
            element.value = text;
            element.dispatchEvent(new Event('input', { bubbles: true }));
        } else {
            // Per div contenteditable
            element.textContent = text;
            
            // Simula digitazione per trigger eventi
            const inputEvent = new InputEvent('input', {
                bubbles: true,
                cancelable: true,
                inputType: 'insertText',
                data: text
            });
            element.dispatchEvent(inputEvent);
        }

        // Simula cambiamento
        await new Promise(resolve => setTimeout(resolve, 500));
    }

    async waitForResponse() {
        return new Promise((resolve, reject) => {
            const timeout = 30000; // 30 secondi timeout
            const startTime = Date.now();
            
            const checkForResponse = () => {
                // Cerca la risposta di Gemini
                const responseSelectors = [
                    '[data-message-author-role="model"]',
                    '.model-response',
                    '.assistant-message',
                    '[role="article"]',
                    '.message-content'
                ];

                for (const selector of responseSelectors) {
                    const elements = document.querySelectorAll(selector);
                    if (elements.length > 0) {
                        const lastResponse = elements[elements.length - 1];
                        const text = lastResponse.textContent || lastResponse.innerText;
                        
                        if (text && text.trim().length > 10) {
                            resolve(text.trim());
                            return;
                        }
                    }
                }

                // Controlla se è passato troppo tempo
                if (Date.now() - startTime > timeout) {
                    reject(new Error('Timeout: Nessuna risposta ricevuta da Gemini'));
                    return;
                }

                // Riprova tra 1 secondo
                setTimeout(checkForResponse, 1000);
            };

            // Inizia a controllare dopo un breve delay
            setTimeout(checkForResponse, 2000);
        });
    }

    notifyReady() {
        // Invia notifica che il bridge è pronto
        chrome.runtime.sendMessage({
            type: 'gemini-web-ready',
            url: window.location.href
        });
    }
}

// Inizializza solo su gemini.google.com
if (window.location.hostname.includes('gemini.google.com')) {
    // Aspetta che la pagina sia completamente caricata
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => {
            new GeminiWebBridge();
        });
    } else {
        new GeminiWebBridge();
    }
} 