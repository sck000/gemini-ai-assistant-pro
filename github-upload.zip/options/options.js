// Internationalization system
function initializeI18n() {
    // Update text content for elements with data-i18n
    const elements = document.querySelectorAll('[data-i18n]');
    elements.forEach(element => {
        if (element) {
            const key = element.getAttribute('data-i18n');
            const message = chrome.i18n.getMessage(key);
            if (message) {
                element.textContent = message;
            }
        }
    });

    // Update placeholder for elements with data-i18n-placeholder
    const placeholderElements = document.querySelectorAll('[data-i18n-placeholder]');
    placeholderElements.forEach(element => {
        if (element) {
            const key = element.getAttribute('data-i18n-placeholder');
            const message = chrome.i18n.getMessage(key);
            if (message) {
                element.placeholder = message;
            }
        }
    });

    // Update title
    const titleElement = document.querySelector('title[data-i18n]');
    if (titleElement) {
        const key = titleElement.getAttribute('data-i18n');
        const message = chrome.i18n.getMessage(key);
        if (message) {
            document.title = message;
        }
    }

    // Update option texts for model selector
    const modelOptions = document.querySelectorAll('#model option[data-i18n]');
    modelOptions.forEach(option => {
        if (option) {
            const key = option.getAttribute('data-i18n');
            const message = chrome.i18n.getMessage(key);
            if (message) {
                option.textContent = message;
            }
        }
    });
}

// Gemini AI Assistant Pro - Options Page
class OptionsManager {
    constructor() {
        this.isLoading = false;
        this.init();
    }

    async init() {
        // Wait a small moment to ensure DOM is fully loaded
        await new Promise(resolve => setTimeout(resolve, 100));
        
        initializeI18n();
        this.setupEventListeners();
        await this.loadSettings();
        this.updateRangeValues();
        await this.checkConnectionStatus();
    }

    setupEventListeners() {
        // Form elements
        document.getElementById('save-settings').addEventListener('click', () => this.saveSettings());
        document.getElementById('test-api').addEventListener('click', () => this.testConnection());
        document.getElementById('reset-settings').addEventListener('click', () => this.resetSettings());
        document.getElementById('toggle-api-key').addEventListener('click', () => this.toggleApiKeyVisibility());

        // Range inputs
        const maxTokensInput = document.getElementById('max-tokens');
        const temperatureInput = document.getElementById('temperature');
        
        if (maxTokensInput) {
            maxTokensInput.addEventListener('input', (e) => {
                const tokensValue = document.getElementById('tokens-value');
                if (tokensValue) {
                    tokensValue.textContent = e.target.value;
                }
            });
        }

        if (temperatureInput) {
            temperatureInput.addEventListener('input', (e) => {
                const tempValue = document.getElementById('temp-value');
                if (tempValue) {
                    tempValue.textContent = parseFloat(e.target.value).toFixed(1);
                }
            });
        }

        // Auto-save on input changes
        document.getElementById('api-key').addEventListener('blur', () => this.autoSave());
        document.getElementById('model').addEventListener('change', () => this.autoSave());
        document.getElementById('max-tokens').addEventListener('change', () => this.autoSave());
        document.getElementById('temperature').addEventListener('change', () => this.autoSave());
        document.getElementById('language').addEventListener('change', () => this.changeLanguage());
    }

    async loadSettings() {
        try {
            const settings = await this.getStoredSettings();
            
            // Populate form fields
            document.getElementById('api-key').value = settings.apiKey || '';
            document.getElementById('model').value = settings.model || 'gemini-1.5-flash';
            document.getElementById('max-tokens').value = settings.maxTokens || 1024;
            document.getElementById('temperature').value = settings.temperature || 0.7;
            document.getElementById('language').value = settings.language || 'en';

            this.updateRangeValues();
        } catch (error) {
            this.showToast('Errore nel caricamento impostazioni', 'error');
        }
    }

    async saveSettings() {
        if (this.isLoading) return;

        this.setLoading(true);
        
        try {
            const settings = {
                apiKey: document.getElementById('api-key').value.trim(),
                model: document.getElementById('model').value,
                maxTokens: parseInt(document.getElementById('max-tokens').value),
                temperature: parseFloat(document.getElementById('temperature').value),
                language: document.getElementById('language').value
            };

            await this.storeSettings(settings);
            this.showToast('Impostazioni salvate con successo!', 'success');
            
            // Update connection status
            await this.checkConnectionStatus();
            
        } catch (error) {
            this.showToast('Errore nel salvataggio impostazioni', 'error');
        } finally {
            this.setLoading(false);
        }
    }

    async testConnection() {
        if (this.isLoading) return;

        const apiKey = document.getElementById('api-key').value.trim();
        
        if (!apiKey) {
            this.showToast('Inserisci prima una API Key', 'warning');
            return;
        }

        this.setLoading(true);
        this.updateStatusCard('🧪', 'Testing API connection...', 'testing');

        try {
            const model = document.getElementById('model').value;
            const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    contents: [{
                        parts: [{
                            text: 'Hello! Test connection.'
                        }]
                    }],
                    generationConfig: {
                        temperature: 0.7,
                        topK: 40,
                        topP: 0.95,
                        maxOutputTokens: 100,
                    }
                })
            });

            if (response.ok) {
                const data = await response.json();
                if (data.candidates && data.candidates[0]) {
                    this.updateStatusCard('✅', 'API connection successful!', 'success');
                    this.showToast('Connessione API funzionante!', 'success');
                } else {
                    throw new Error('Invalid response format');
                }
            } else {
                const errorData = await response.json().catch(() => ({}));
                if (response.status === 403) {
                    throw new Error('API Key non valida o quota esaurita');
                } else if (response.status === 429) {
                    throw new Error('Troppe richieste. Attendi qualche secondo');
                } else {
                    throw new Error(`API Error: ${response.status}`);
                }
            }

        } catch (error) {
            this.updateStatusCard('❌', `Test failed: ${error.message}`, 'error');
            this.showToast(`Test fallito: ${error.message}`, 'error');
        } finally {
            this.setLoading(false);
        }
    }

    async resetSettings() {
        if (this.isLoading) return;

        if (!confirm('Vuoi davvero ripristinare tutte le impostazioni ai valori predefiniti?')) {
            return;
        }

        this.setLoading(true);

        try {
            const defaultSettings = {
                apiKey: '',
                model: 'gemini-1.5-flash',
                maxTokens: 1024,
                temperature: 0.7,
                language: 'en'
            };

            await this.storeSettings(defaultSettings);
            await this.loadSettings();
            
            this.showToast('Impostazioni ripristinate ai valori predefiniti', 'success');
            await this.checkConnectionStatus();

        } catch (error) {
            this.showToast('Errore nel ripristino impostazioni', 'error');
        } finally {
            this.setLoading(false);
        }
    }

    async autoSave() {
        // Auto-save con debounce
        clearTimeout(this.autoSaveTimeout);
        this.autoSaveTimeout = setTimeout(async () => {
            await this.saveSettings();
        }, 1000);
    }

    toggleApiKeyVisibility() {
        const apiKeyInput = document.getElementById('api-key');
        const toggleBtn = document.getElementById('toggle-api-key');
        
        if (apiKeyInput.type === 'password') {
            apiKeyInput.type = 'text';
            toggleBtn.textContent = '🙈';
        } else {
            apiKeyInput.type = 'password';
            toggleBtn.textContent = '👁️';
        }
    }

    updateRangeValues() {
        const tokensValue = document.getElementById('tokens-value');
        const maxTokens = document.getElementById('max-tokens');
        const tempValue = document.getElementById('temp-value');
        const temperature = document.getElementById('temperature');
        
        if (tokensValue && maxTokens) {
            tokensValue.textContent = maxTokens.value;
        }
        
        if (tempValue && temperature) {
            tempValue.textContent = parseFloat(temperature.value).toFixed(1);
        }
    }

    async checkConnectionStatus() {
        const apiKey = document.getElementById('api-key').value.trim();
        
        if (!apiKey) {
            this.updateStatusCard('⚠️', 'API Key non configurata', 'warning');
            return;
        }

        this.updateStatusCard('🔄', 'Verificando connessione...', 'loading');

        try {
            // Quick validation check
            const model = document.getElementById('model').value;
            const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}?key=${apiKey}`, {
                method: 'GET'
            });

            if (response.ok) {
                this.updateStatusCard('✅', 'API ready - Connessione attiva', 'success');
            } else if (response.status === 403) {
                this.updateStatusCard('❌', 'API Key non valida', 'error');
            } else {
                this.updateStatusCard('⚠️', 'Problemi di connessione', 'warning');
            }

        } catch (error) {
            this.updateStatusCard('❌', 'Errore di rete', 'error');
        }
    }

    updateStatusCard(icon, message, type) {
        const statusCard = document.getElementById('connection-status');
        
        let className = 'status-loading';
        if (type === 'success') className = 'status-success';
        else if (type === 'error') className = 'status-error';
        else if (type === 'warning') className = 'status-warning';
        
        statusCard.innerHTML = `
            <div class="${className}" style="
                display: flex;
                align-items: center;
                justify-content: center;
                gap: 12px;
                padding: 20px;
                color: ${type === 'success' ? '#4CAF50' : 
                       type === 'error' ? '#dc3545' :
                       type === 'warning' ? '#ffc107' : '#666'};
                font-weight: 500;
            ">
                <span style="font-size: 24px;">${icon}</span>
                <span>${message}</span>
                ${type === 'loading' || type === 'testing' ? '<div class="spinner"></div>' : ''}
            </div>
        `;
    }

    setLoading(loading) {
        this.isLoading = loading;
        const buttons = document.querySelectorAll('.btn');
        const container = document.querySelector('.container');
        
        if (loading) {
            container.classList.add('loading');
            buttons.forEach(btn => btn.disabled = true);
        } else {
            container.classList.remove('loading');
            buttons.forEach(btn => btn.disabled = false);
        }
    }

    async changeLanguage() {
        const selectedLanguage = document.getElementById('language').value;
        
        try {
            // Save language preference
            await this.storeSettings({
                ...await this.getStoredSettings(),
                language: selectedLanguage
            });
            
            this.showToast('Language preference saved! Please restart the extension.', 'success');
            
            // Optional: Reload the extension programmatically
            if (chrome.runtime.reload) {
                setTimeout(() => {
                    chrome.runtime.reload();
                }, 1500);
            }
            
        } catch (error) {
            this.showToast('Error saving language preference', 'error');
        }
    }

    showToast(message, type = 'success') {
        // Remove existing toast
        const existingToast = document.querySelector('.toast');
        if (existingToast) {
            existingToast.remove();
        }

        // Create new toast
        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        toast.textContent = message;
        
        document.body.appendChild(toast);
        
        // Animate in
        setTimeout(() => toast.classList.add('show'), 100);
        
        // Auto-remove after 3 seconds
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => toast.remove(), 300);
        }, 3000);
    }

    // Storage methods
    async getStoredSettings() {
        return new Promise((resolve) => {
            chrome.storage.sync.get(['apiKey', 'model', 'maxTokens', 'temperature', 'language'], (result) => {
                resolve(result);
            });
        });
    }

    async storeSettings(settings) {
        return new Promise((resolve, reject) => {
            chrome.storage.sync.set(settings, () => {
                if (chrome.runtime.lastError) {
                    reject(chrome.runtime.lastError);
                } else {
                    resolve();
                }
            });
        });
    }
}

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    new OptionsManager();
}); 