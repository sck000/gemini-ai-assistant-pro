# Changelog v2.6.1 - Language & Model Updates

## 🌍 Internationalization Improvements

### ✅ Changes Made

1. **Default Language Changed to English**
   - Changed `default_locale` from "it" to "en" in manifest.json
   - Extension now starts in English by default

2. **Language Selector Restored**
   - Added "Language Preferences" section in settings
   - Users can now change interface language
   - Supports: English, Italian, Spanish, French, German
   - Extension automatically reloads after language change

3. **Model Options Updated**
   - ❌ **REMOVED**: `gemini-2.5-pro-preview-05-06` (not compatible with free API)
   - ✅ **KEPT**: All other models that work with free API:
     - Gemini 1.5 Flash (recommended)
     - Gemini 1.5 Pro
     - Gemini 2.0 Flash (experimental)
     - Gemini 2.5 Flash (preview)

4. **Full Translation Support**
   - Popup interface now uses i18n system (31 UI elements)
   - **✅ FIXED**: Settings page now properly translates (40 UI elements)
   - Placeholder texts translated
   - All quick actions and tools translated
   - **🐛 BUG FIX**: Settings page language now matches selected interface language

## 🔧 Technical Changes

### Files Modified:
- `manifest.json` - Changed default locale
- `options/options.html` - Removed 2.5 Pro model, added language selector, **added i18n attributes**
- `options/options.js` - Added language change functionality, **added i18n initialization**
- `popup/popup.html` - Added i18n attributes to all text elements
- `popup/popup.js` - Added translation initialization system
- `_locales/en/messages.json` - **Added 47 new translation keys for settings**
- `_locales/it/messages.json` - **Added 47 new translation keys for settings**

### New Features:
- Dynamic language switching
- Automatic extension reload after language change
- Proper fallback to English for missing translations
- **🎯 Settings page language synchronization**

## 🚀 How to Use

1. **Change Language**: Go to Settings → Language Preferences
2. **Select Model**: Choose from available models (2.5 Pro removed)
3. **API Compatibility**: All remaining models work with free Google AI Studio API
4. **Language Sync**: Settings page will now display in the selected language

## 📦 Build Information

- Version: 2.6.1
- Build Status: ✅ Successful
- Validation: ✅ Passed
- Package: `gemini-ai-assistant-pro-v2.6.0.zip` (updated)

## 🔍 Testing Checklist

- [x] Default language is English
- [x] Language selector works in settings
- [x] Gemini 2.5 Pro model removed
- [x] All other models present
- [x] Popup uses translation system (31 elements)
- [x] **Settings page uses translation system (40 elements)**
- [x] Extension builds successfully
- [x] Manifest validation passes
- [x] **Settings page language matches interface language**

## 🐛 Bug Fixes

### Issue: Settings page language mismatch
**Problem**: Settings page was displayed in Italian even when English was selected as interface language.

**Solution**: 
1. Added 47 new translation keys for all settings page elements
2. Implemented i18n initialization in options.js
3. Added data-i18n attributes to all text elements in options.html
4. Settings page now properly syncs with selected language

**Affected Files**: `options/options.html`, `options/options.js`, `_locales/*/messages.json` 